import sys
import os
import json
import subprocess
import csv
import random
import numpy as np
import matplotlib
matplotlib.use('Qt5Agg')
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                            QPushButton, QLineEdit, QLabel, QFileDialog, QMessageBox, QTableWidget, QTableWidgetItem)
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

# DataPoint class
class DataPoint:
    def __init__(self, features, label):
        self.features = features
        self.label = label

# Data handling function
def load_csv(path):
    data = []
    with open(path, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            if len(row) >= 5:
                features = [float(x) for x in row[:4]]
                label = int(row[4])
                data.append(DataPoint(features, label))
    return data

# Plotting class
class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes1 = fig.add_subplot(111)
        self.axes2 = self.axes1.twinx()  # Secondary y-axis for loss
        super().__init__(fig)
        self.setParent(parent)
        self.accuracy_data = []
        self.loss_data = []
        self.epochs = []

    def update_plot(self, epoch, accuracy, loss):
        self.epochs.append(epoch)
        self.accuracy_data.append(accuracy)
        self.loss_data.append(loss)
        self.axes1.clear()
        self.axes2.clear()
        self.axes1.plot(self.epochs, self.accuracy_data, 'r-', label='Accuracy')
        self.axes2.plot(self.epochs, self.loss_data, 'b-', label='Loss')
        self.axes1.set_xlabel('Epochs')
        self.axes1.set_ylabel('Accuracy', color='r')
        self.axes2.set_ylabel('Loss', color='b')
        self.axes1.set_title('Training Progress')
        self.axes1.tick_params(axis='y', colors='r')
        self.axes2.tick_params(axis='y', colors='b')
        self.axes1.grid(True)
        lines1, labels1 = self.axes1.get_legend_handles_labels()
        lines2, labels2 = self.axes2.get_legend_handles_labels()
        self.axes1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')
        self.draw()

    def reset(self):
        self.epochs = []
        self.accuracy_data = []
        self.loss_data = []
        self.axes1.clear()
        self.axes2.clear()
        self.draw()

# Main GUI
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Soil Fertility Predictor")
        self.setGeometry(100, 100, 700, 700)  # Increased height for new inputs
        self.main_widget = QWidget(self)
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(15)

        # Apply stylesheet
        self.setStyleSheet("""
            QMainWindow {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                            stop:0 #f0f4f8, stop:1 #d9e2ec);
            }
            QLabel {
                font: 14px 'Segoe UI';
                color: #333;
            }
            QLineEdit {
                padding: 8px;
                border: 1px solid #ccc;
                border-radius: 5px;
                font: 14px 'Segoe UI';
            }
            QPushButton {
                background-color: #0078d4;
                color: white;
                padding: 8px 15px;
                border: none;
                border-radius: 5px;
                font: 14px 'Segoe UI';
            }
            QPushButton:hover {
                background-color: #005ba1;
            }
            QPushButton:pressed {
                background-color: #004080;
            }
            QTableWidget {
                font: 12px 'Consolas';
                color: #333;
                background: #fff;
                border: 1px solid #ccc;
                border-radius: 5px;
                gridline-color: #ccc;
            }
            QTableWidget::item {
                padding: 5px;
            }
            QHeaderView::section {
                background-color: #f0f4f8;
                padding: 5px;
                border: 1px solid #ccc;
                font: bold 12px 'Segoe UI';
                color: #333;
            }
        """)

        # CSV loading
        self.csv_layout = QHBoxLayout()
        self.csv_layout.setSpacing(10)
        self.csv_input = QLineEdit(self)
        self.csv_input.setPlaceholderText("Select or enter CSV file path")
        self.browse_btn = QPushButton("Browse", self)
        self.browse_btn.clicked.connect(self.browse_csv)
        self.load_btn = QPushButton("Load Data", self)
        self.load_btn.clicked.connect(self.load_data)
        self.csv_layout.addWidget(QLabel("CSV File:"))
        self.csv_layout.addWidget(self.csv_input)
        self.csv_layout.addWidget(self.browse_btn)
        self.csv_layout.addWidget(self.load_btn)
        self.layout.addLayout(self.csv_layout)

        # Training parameters
        self.train_layout = QHBoxLayout()
        self.train_layout.setSpacing(10)
        self.epochs_input = QLineEdit("1000", self)
        self.epochs_input.setMaximumWidth(100)
        self.lr_input = QLineEdit("0.001", self)
        self.lr_input.setMaximumWidth(100)
        self.train_btn = QPushButton("Train Model", self)
        self.train_btn.clicked.connect(self.train_model)
        self.train_layout.addWidget(QLabel("Epochs:"))
        self.train_layout.addWidget(self.epochs_input)
        self.train_layout.addWidget(QLabel("Learning Rate:"))
        self.train_layout.addWidget(self.lr_input)
        self.train_layout.addWidget(self.train_btn)
        self.train_layout.addStretch()
        self.layout.addLayout(self.train_layout)

        # Manual prediction inputs
        self.predict_layout = QVBoxLayout()
        self.predict_layout.setSpacing(10)
        self.predict_inputs_layout = QHBoxLayout()
        self.temp_input = QLineEdit(self)
        self.temp_input.setPlaceholderText("e.g., 25.0")
        self.temp_input.setMaximumWidth(100)
        self.hum_input = QLineEdit(self)
        self.hum_input.setPlaceholderText("e.g., 60.0")
        self.hum_input.setMaximumWidth(100)
        self.ph_input = QLineEdit(self)
        self.ph_input.setPlaceholderText("e.g., 6.5")
        self.ph_input.setMaximumWidth(100)
        self.moist_input = QLineEdit(self)
        self.moist_input.setPlaceholderText("e.g., 30.0")
        self.moist_input.setMaximumWidth(100)
        self.predict_inputs_layout.addWidget(QLabel("Temperature:"))
        self.predict_inputs_layout.addWidget(self.temp_input)
        self.predict_inputs_layout.addWidget(QLabel("Humidity:"))
        self.predict_inputs_layout.addWidget(self.hum_input)
        self.predict_inputs_layout.addWidget(QLabel("Soil pH:"))
        self.predict_inputs_layout.addWidget(self.ph_input)
        self.predict_inputs_layout.addWidget(QLabel("Moisture:"))
        self.predict_inputs_layout.addWidget(self.moist_input)
        self.predict_layout.addLayout(self.predict_inputs_layout)

        # Predict button and result
        self.predict_btn_layout = QHBoxLayout()
        self.predict_btn = QPushButton("Predict", self)
        self.predict_btn.clicked.connect(self.predict_manual)
        self.predict_result = QLabel("Prediction: None")
        self.predict_btn_layout.addWidget(self.predict_btn)
        self.predict_btn_layout.addWidget(self.predict_result)
        self.predict_btn_layout.addStretch()
        self.predict_layout.addLayout(self.predict_btn_layout)
        self.layout.addLayout(self.predict_layout)

        # Training status
        self.status_layout = QHBoxLayout()
        self.status_layout.setSpacing(10)
        self.status_label = QLabel("Status: Ready")
        self.status_label.setStyleSheet("font: bold 14px 'Segoe UI';")
        self.epoch_label = QLabel("Epoch: 0")
        self.loss_label = QLabel("Loss: 0.0000")
        self.status_layout.addWidget(self.status_label)
        self.status_layout.addWidget(self.epoch_label)
        self.status_layout.addWidget(self.loss_label)
        self.status_layout.addStretch()
        self.layout.addLayout(self.status_layout)

        # Plot
        self.canvas = PlotCanvas(self, width=6, height=4, dpi=100)
        self.layout.addWidget(self.canvas)

        # Sample predictions table
        self.pred_table = QTableWidget(self)
        self.pred_table.setRowCount(0)
        self.pred_table.setColumnCount(6)
        self.pred_table.setHorizontalHeaderLabels(["Temp", "Hum", "pH", "Moist", "Actual", "Predicted"])
        self.pred_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.pred_table.setSelectionMode(QTableWidget.NoSelection)
        self.pred_table.setShowGrid(True)
        self.pred_table.setMinimumHeight(150)
        self.pred_table.horizontalHeader().setStretchLastSection(True)
        self.layout.addWidget(self.pred_table)

        self.layout.addStretch()

        self.data = None
        self.test_data = None
        self.min_vals = None
        self.max_vals = None

    def browse_csv(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select CSV", "", "CSV Files (*.csv)")
        if file_path:
            self.csv_input.setText(file_path)

    def load_data(self):
        path = self.csv_input.text()
        if not os.path.exists(path):
            QMessageBox.critical(self, "Error", "CSV file not found!")
            return
        try:
            self.data = load_csv(path)
            self.status_label.setText(f"Status: Loaded {len(self.data)} points")
            self.epoch_label.setText("Epoch: 0")
            self.loss_label.setText("Loss: 0.0000")
            self.pred_table.setRowCount(0)
            self.canvas.reset()
            self.predict_result.setText("Prediction: None")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load CSV: {e}")
            self.status_label.setText("Status: Error")

    def train_model(self):
        if not self.data:
            QMessageBox.critical(self, "Error", "Load data first!")
            return
        try:
            epochs = int(self.epochs_input.text())
            lr = float(self.lr_input.text())
        except ValueError:
            QMessageBox.critical(self, "Error", "Invalid epochs or learning rate!")
            return

        self.status_label.setText("Status: Training...")
        self.canvas.reset()
        self.pred_table.setRowCount(0)
        self.predict_result.setText("Prediction: None")
        QApplication.processEvents()

        try:
            # Run the external training command
            process = subprocess.Popen(
                ["./target/release/soilqt", "--train", self.csv_input.text(), str(epochs), str(lr)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )

            # Read output line by line
            while True:
                line = process.stdout.readline()
                if not line and process.poll() is not None:
                    break
                if line:
                    print(line.strip())  # Print to terminal
                    try:
                        data = json.loads(line.strip())
                        if "epoch" in data:
                            epoch = data["epoch"]
                            accuracy = data["accuracy"]
                            loss = data["loss"]
                            self.epoch_label.setText(f"Epoch: {epoch}")
                            self.loss_label.setText(f"Loss: {loss:.4f}")
                            self.canvas.update_plot(epoch, accuracy, loss)
                            QApplication.processEvents()
                        elif "test_accuracy" in data:
                            val_accuracy = data["val_accuracy"]
                            test_accuracy = data["test_accuracy"]
                            self.status_label.setText(
                                f"Status: Done. Val accuracy: {val_accuracy:.2f}%, Test accuracy: {test_accuracy:.2f}%"
                            )
                    except json.JSONDecodeError:
                        continue

            # Check for errors
            return_code = process.wait()
            if return_code != 0:
                error_output = process.stderr.read()
                self.status_label.setText(f"Training failed: {error_output}")
                QMessageBox.critical(self, "Error", f"Training failed: {error_output}")
                return

            # Load scaler
            with open("scaler.bin", "r") as f:
                scaler = json.load(f)
                self.min_vals = scaler["min_vals"]
                self.max_vals = scaler["max_vals"]

            # Select 10 random test data
            self.test_data = random.sample(self.data, min(10, len(self.data)))

            # Populate sample predictions table
            self.pred_table.setRowCount(len(self.test_data))
            for row, point in enumerate(self.test_data):
                features = point.features
                result = subprocess.run(
                    [
                        "./target/release/soilqt",
                        "--predict",
                        str(features[0]),
                        str(features[1]),
                        str(features[2]),
                        str(features[3])
                    ],
                    capture_output=True, text=True
                )
                if result.returncode != 0:
                    raise Exception(f"Prediction failed: {result.stderr}")
                pred_result = json.loads(result.stdout)
                pred = pred_result["prediction"]
                self.pred_table.setItem(row, 0, QTableWidgetItem(f"{features[0]:.1f}"))
                self.pred_table.setItem(row, 1, QTableWidgetItem(f"{features[1]:.1f}"))
                self.pred_table.setItem(row, 2, QTableWidgetItem(f"{features[2]:.1f}"))
                self.pred_table.setItem(row, 3, QTableWidgetItem(f"{features[3]:.1f}"))
                self.pred_table.setItem(row, 4, QTableWidgetItem("Fertile" if point.label else "Not Fertile"))
                self.pred_table.setItem(row, 5, QTableWidgetItem("Fertile" if pred else "Not Fertile"))

            self.pred_table.resizeColumnsToContents()

        except Exception as e:
            self.status_label.setText(f"Error during training: {str(e)}")
            QMessageBox.critical(self, "Error", f"Error during training: {str(e)}")

    def predict_manual(self):
        # Check if model and scaler exist
        if not (os.path.exists("model.bin") and os.path.exists("scaler.bin")):
            QMessageBox.critical(self, "Error", "Train a model first to generate model.bin and scaler.bin!")
            self.predict_result.setText("Prediction: Error")
            return

        # Get and validate inputs
        try:
            temp = float(self.temp_input.text())
            hum = float(self.hum_input.text())
            ph = float(self.ph_input.text())
            moist = float(self.moist_input.text())
        except ValueError:
            QMessageBox.critical(self, "Error", "Please enter valid numeric values for all inputs!")
            self.predict_result.setText("Prediction: Error")
            return

        # Run prediction
        try:
            result = subprocess.run(
                [
                    "./target/release/soilqt",
                    "--predict",
                    str(temp),
                    str(hum),
                    str(ph),
                    str(moist)
                ],
                capture_output=True, text=True
            )
            if result.returncode != 0:
                raise Exception(f"Prediction failed: {result.stderr}")
            pred_result = json.loads(result.stdout)
            pred = pred_result["prediction"]
            probability = pred_result["probability"]
            result_text = f"Prediction: {'Fertile' if pred else 'Not Fertile'} (Probability: {probability:.3f})"
            self.predict_result.setText(result_text)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Prediction failed: {str(e)}")
            self.predict_result.setText("Prediction: Error")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())