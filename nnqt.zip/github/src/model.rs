//src/model.rs
use rand::distributions::{Distribution, Uniform};
use serde::{Deserialize, Serialize};
use serde_json;

#[derive(Serialize, Deserialize, Default)]
pub struct Sigmoid;

impl Sigmoid {
    fn activate(&self, x: f64) -> f64 {
        1.0 / (1.0 + (-x).exp())
    }

    fn derivative(&self, x: f64) -> f64 {
        let s = self.activate(x);
        s * (1.0 - s)
    }
}

#[derive(Serialize, Deserialize)]
pub struct NeuralNetwork {
    input_size: usize,
    hidden_size: usize,
    output_size: usize,
    weights1: Vec<Vec<f64>>,
    weights2: Vec<Vec<f64>>,
    bias1: Vec<f64>,
    bias2: Vec<f64>,
    #[serde(skip)]
    activation: Sigmoid,
}

impl NeuralNetwork {
    pub fn new(input_size: usize, hidden_size: usize, output_size: usize) -> Self {
        let mut rng = rand::thread_rng();
        let weight_distribution = Uniform::from(-0.5..0.5);

        let mut weights1 = vec![vec![0.0; input_size]; hidden_size];
        let mut weights2 = vec![vec![0.0; hidden_size]; output_size];
        let bias1 = vec![0.0; hidden_size];
        let bias2 = vec![0.0; output_size];

        for i in 0..hidden_size {
            for j in 0..input_size {
                weights1[i][j] = weight_distribution.sample(&mut rng);
            }
        }

        for i in 0..output_size {
            for j in 0..hidden_size {
                weights2[i][j] = weight_distribution.sample(&mut rng);
            }
        }

        NeuralNetwork {
            input_size,
            hidden_size,
            output_size,
            weights1,
            weights2,
            bias1,
            bias2,
            activation: Sigmoid,
        }
    }

    pub fn forward(&self, inputs: &[f64]) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
        let mut hidden_layer = vec![0.0; self.hidden_size];
        for i in 0..self.hidden_size {
            for j in 0..self.input_size {
                hidden_layer[i] += inputs[j] * self.weights1[i][j];
            }
            hidden_layer[i] += self.bias1[i];
            hidden_layer[i] = self.activation.activate(hidden_layer[i]);
        }

        let mut output_layer = vec![0.0; self.output_size];
        for i in 0..self.output_size {
            for j in 0..self.hidden_size {
                output_layer[i] += hidden_layer[j] * self.weights2[i][j];
            }
            output_layer[i] += self.bias2[i];
            output_layer[i] = self.activation.activate(output_layer[i]);
        }

        (hidden_layer, output_layer.clone(), output_layer)
    }

    fn backward(&mut self, inputs: &[f64], hidden: &[f64], output: &[f64], target: u8, learning_rate: f64) {
        let target_f64 = target as f64;
        let error = output[0] - target_f64;

        let d_output = error * self.activation.derivative(output[0]);

        for i in 0..self.hidden_size {
            self.weights2[0][i] -= learning_rate * d_output * hidden[i];
        }
        self.bias2[0] -= learning_rate * d_output;

        let mut d_hidden = vec![0.0; self.hidden_size];
        for i in 0..self.hidden_size {
            d_hidden[i] = d_output * self.weights2[0][i] * self.activation.derivative(hidden[i]);
        }

        for i in 0..self.hidden_size {
            for j in 0..self.input_size {
                self.weights1[i][j] -= learning_rate * d_hidden[i] * inputs[j];
            }
            self.bias1[i] -= learning_rate * d_hidden[i];
        }
    }

    pub fn train(&mut self, data: &[super::data::DataPoint], epochs: usize, learning_rate: f64, _val_data: &[super::data::DataPoint]) -> (Vec<f64>, Vec<f64>) {
        let mut train_accuracy_history = Vec::with_capacity(epochs);
        let mut train_loss_history = Vec::with_capacity(epochs);

        for epoch in 0..epochs {
            let mut correct_predictions = 0;
            let mut total_loss = 0.0;

            for data_point in data {
                let (hidden, output, _) = self.forward(&data_point.features);
                let error = output[0] - data_point.label as f64;
                total_loss += error * error;
                self.backward(&data_point.features, &hidden, &output, data_point.label, learning_rate);

                let prediction = if output[0] > 0.5 { 1 } else { 0 };
                if prediction == data_point.label as u8 {
                    correct_predictions += 1;
                }
            }

            let accuracy = correct_predictions as f64 / data.len() as f64;
            let avg_loss = total_loss / data.len() as f64;
            train_accuracy_history.push(accuracy);
            train_loss_history.push(avg_loss);

            // Print progress every 10 epochs
            if (epoch + 1) % 10 == 0 {
                let rounded_accuracy = (accuracy * 1000.0).round() / 1000.0;
                let rounded_loss = (avg_loss * 1000.0).round() / 1000.0;

                // Human-readable output
                println!("Epoch: {}, Loss: {:.3}, Accuracy: {:.3}%", epoch + 1, avg_loss, accuracy * 100.0);

                // JSON output with 3 decimal places
                println!(
                    "{}",
                    serde_json::json!({
                        "epoch": epoch + 1,
                        "accuracy": rounded_accuracy,
                        "loss": rounded_loss
                    })
                );
            }
        }

        (train_accuracy_history, train_loss_history)
    }

    pub fn predict(&self, features: &[f64]) -> u8 {
        let (_, _, output) = self.forward(features);
        if output[0] > 0.5 { 1 } else { 0 }
    }

    pub fn predict_with_probability(&self, features: &[f64]) -> (f64, u8) {
        let (_, _, output) = self.forward(features);
        let probability = output[0];
        let prediction = if probability > 0.5 { 1 } else { 0 };
        (probability, prediction)
    }

    pub fn evaluate(&self, data: &[super::data::DataPoint]) -> f64 {
        let mut correct_predictions = 0;

        for data_point in data {
            let prediction = self.predict(&data_point.features);
            if prediction == data_point.label {
                correct_predictions += 1;
            }
        }

        correct_predictions as f64 / data.len() as f64
    }
}
