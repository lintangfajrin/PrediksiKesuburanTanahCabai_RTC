//src/data.rs
use std::fs::File;
use std::io::{self, BufRead, BufReader};
use rand::Rng;

#[derive(Clone)]
pub struct DataPoint {
    pub features: Vec<f64>,
    pub label: u8,
}

pub fn load_csv(path: &str) -> Result<Vec<DataPoint>, io::Error> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);
    let mut data = Vec::new();

    for (i, line) in reader.lines().enumerate() {
        if let Ok(text) = line {
            if i == 0 {
                continue;
            }

            let values: Vec<&str> = text.split(',').collect();
            if values.len() >= 5 {
                let features = vec![
                    values[0].parse::<f64>().unwrap_or(0.0),
                    values[1].parse::<f64>().unwrap_or(0.0),
                    values[2].parse::<f64>().unwrap_or(0.0),
                    values[3].parse::<f64>().unwrap_or(0.0),
                ];
                let label = values[4].parse::<u8>().unwrap_or(0);
                data.push(DataPoint { features, label });
            }
        }
    }

    Ok(data)
}

pub fn normalize_features(data: &mut [DataPoint]) -> (Vec<f64>, Vec<f64>) {
    let n_features = data[0].features.len();
    let mut min_values = vec![f64::MAX; n_features];
    let mut max_values = vec![f64::MIN; n_features];

    for point in data.iter() {
        for (i, &value) in point.features.iter().enumerate() {
            if value < min_values[i] {
                min_values[i] = value;
            }
            if value > max_values[i] {
                max_values[i] = value;
            }
        }
    }

    for point in data.iter_mut() {
        for i in 0..n_features {
            let range = max_values[i] - min_values[i];
            if range > 0.0 {
                point.features[i] = (point.features[i] - min_values[i]) / range;
            } else {
                point.features[i] = 0.5;
            }
        }
    }

    (min_values, max_values)
}

pub fn split_data(data: &[DataPoint], train_ratio: f64) -> (Vec<DataPoint>, Vec<DataPoint>) {
    let mut rng = rand::thread_rng();
    let mut train_data = Vec::new();
    let mut test_data = Vec::new();

    for data_point in data {
        if rng.gen::<f64>() < train_ratio {
            train_data.push(DataPoint {
                features: data_point.features.clone(),
                label: data_point.label,
            });
        } else {
            test_data.push(DataPoint {
                features: data_point.features.clone(),
                label: data_point.label,
            });
        }
    }

    (train_data, test_data)
}
