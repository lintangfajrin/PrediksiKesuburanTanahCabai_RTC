fn main() {
    // Lookup table untuk nilai sinus dan kosinus
    let sin_table: [f64; 13] = [
        0.000, 0.500, 0.866, 1.000, 0.866, 0.500, 0.000,
        -0.500, -0.866, -1.000, -0.866, -0.500, 0.000
    ];

    let cos_table: [f64; 13] = [
        1.000, 0.866, 0.500, 0.000, -0.500, -0.866, -1.000,
        -0.866, -0.500, 0.000, 0.500, 0.866, 1.000
    ];

    // Daftar sudut dalam derajat yang sesuai dengan lookup table
    let angles: [i32; 13] = [
        0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330, 360
    ];

    // Cetak hasil lookup table
    println!("{:<8} {:<8} {:<8}", "Sudut", "Sin(θ)", "Cos(θ)");
    println!("--------------------------------");

    for i in 0..angles.len() {
        println!("{:<8} {:<8.3} {:<8.3}", angles[i], sin_table[i], cos_table[i]);
    }

    // Contoh pencarian nilai sinus dan kosinus dari sudut tertentu
    let input_angle = 60; //
    if let Some(index) = angles.iter().position(|&x| x == input_angle) {
        println!(
            "\nNilai Sin({}) = {:.3}, Cos({}) = {:.3}",
            input_angle, sin_table[index], input_angle, cos_table[index]
        );
    } else {
        println!("\nSudut tidak ditemukan dalam lookup table.");
    }
}
