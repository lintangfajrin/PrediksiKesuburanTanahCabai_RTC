use std::f64::consts::PI;
use std::io;

fn factorial(n: u32) -> f64 {
    (1..=n).fold(1.0, |acc, x| acc * x as f64)
}

fn sine_taylor(x: f64, terms: u32) -> f64 {
    let mut sum = 0.0;
    let mut sign = 1.0;

    for i in 0..terms {
        let exponent = 2 * i + 1;
        let term = sign * (x.powi(exponent as i32) / factorial(exponent));
        sum += term;
        sign *= -1.0;
    }

    sum
}

fn cosine_taylor(x: f64, terms: u32) -> f64 {
    let mut sum = 0.0;
    let mut sign = 1.0;

    for i in 0..terms {
        let exponent = 2 * i;
        let term = sign * (x.powi(exponent as i32) / factorial(exponent));
        sum += term;
        sign *= -1.0;
    }

    sum
}

fn deg_to_rad(deg: f64) -> f64 {
    deg * PI / 180.0
}

fn main() {
    let terms = 10; // Jumlah suku dalam deret Taylor
    let mut input = String::new();

    loop {
        println!("Masukkan sudut dalam derajat (atau ketik 'exit' untuk keluar): ");
        input.clear();
        io::stdin().read_line(&mut input).expect("Gagal membaca input");
        let input = input.trim();

        if input.eq_ignore_ascii_case("exit") {
            println!("Keluar dari program.");
            break;
        }

        let x_deg: f64 = match input.parse() {
            Ok(num) => num,
            Err(_) => {
                println!("Masukkan angka yang valid.");
                continue;
            }
        };

        let x_rad = deg_to_rad(x_deg);
        let sin_approx = sine_taylor(x_rad, terms);
        let cos_approx = cosine_taylor(x_rad, terms);

        println!("sin({}°) ≈ {}", x_deg, sin_approx);
        println!("cos({}°) ≈ {}", x_deg, cos_approx);
    }
}
